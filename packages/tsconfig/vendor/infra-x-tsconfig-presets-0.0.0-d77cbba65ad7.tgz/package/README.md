# @infra-x/tsconfig-presets

组合 TypeScript 编译选项，返回纯配置数据。无运行时依赖；不含 CLI、文件读写、选项校验或生成器。

当前为本地 `0.0.0`，尚未发布。下列导入示例适用于 workspace 或已安装本地打包产物的项目。

## 直接生成配置

日常使用通过 `infra-code` 中的 `@infra-x/tsconfig` 生成器直接写出配置。本包维护配置内容，生成器已用固定 tarball 开发快照接入；当前接入改动尚未发布。修改本包后需重新打包并同步生成器快照，才能生成更新后的配置。

先在本仓库安装依赖并构建，再按根 README 准备生成器。从本仓库根目录运行：

```sh
# React 前端
bun run tsconfig --runtime browser --module bundler --framework react --cwd /绝对路径/应用

# Electron + React
bun run tsconfig --preset electron-vite --framework react --cwd /绝对路径/应用
```

目标应用目录需已存在，并自行提供 TypeScript 和相应框架、运行时类型。第一条生成 `tsconfig.json`，第二条生成根、Node、renderer 三份配置。构建后的生成器 tarball 内联本包，安装该产物的应用不需要本地预设仓库。

## 函数 API

需要开发生成器或自定义组合时使用下列 API：

```ts
import { base, buildBundler, composeAtoms, runtimeNode } from '@infra-x/tsconfig-presets'

const compilerOptions = composeAtoms(base(), runtimeNode(), buildBundler())
```

将 `compilerOptions` 放入应用自己的 `tsconfig` 配置对象，或交给生成器。使用 `ArrayControl` 时，先由 `mergeCompilerOptions` 或 `normalizeCompilerOptions` 转成普通数组。

## Atoms

| 函数                                 | 配置用途                                     |
| ------------------------------------ | -------------------------------------------- |
| `base()`                             | 严格检查、增量缓存、模块隔离                 |
| `runtimeNode()` / `runtimeBun()`     | Node / Bun 全局类型与 `esnext` 库            |
| `runtimeBrowser()` / `runtimeEdge()` | 浏览器 DOM 库 / 仅 `esnext` 库               |
| `buildBundler()`                     | `module: preserve`、Bundler 解析、`noEmit`   |
| `buildTscEmit()`                     | NodeNext 解析与 `dist` 输出                  |
| `projectLib()`                       | 声明输出、独立声明检查、禁用 JavaScript 输入 |
| `frameworkReact()`                   | `react-jsx`                                  |
| `frameworkNextjs()`                  | `react-jsx`、Preserve 模块、Bundler 解析     |
| `frameworkNestjs()`                  | 装饰器及其元数据，放宽属性初始化检查         |
| `testingVitest()`                    | `vitest/globals` 全局类型                    |
| `strictErasable()`                   | `erasableSyntaxOnly`                         |

Bundler 和 Electron 输入使用 `module: preserve`，要求 TypeScript 5.4+。`base()` 与基本 NodeNext 组合要求 TypeScript 5.0+；可选 atoms 和应用依赖可能要求更高版本。[1][2]

## 合并

| API                                     | 标量                       | 普通对象                   | 数组                     |
| --------------------------------------- | -------------------------- | -------------------------- | ------------------------ |
| `composeAtoms(...atoms)`                | 后者覆盖                   | 整个对象由后者覆盖         | 追加并去重               |
| `mergeCompilerOptions(base, overrides)` | 后者覆盖；忽略 `undefined` | 合并一层，同名键由后者覆盖 | 默认追加并去重；支持控制 |

`lib`、`types`、`plugins` 的 `ArrayField<T>` 接受数组、`'none'` 或 `{ merge: 'append' | 'replace' | 'none', value?: T[] }`。其他字段不解释控制语法；例如 `module: 'none'` 保留为标量，`paths.merge` 保留为普通路径别名。消费端仍须验证实际 TypeScript 版本支持的选项。

`composeAtoms` 只组合数据，不执行数组控制；由后续合并或规范化处理。这些函数不修改传入对象。

```ts
import { mergeCompilerOptions, normalizeCompilerOptions } from '@infra-x/tsconfig-presets'

const options = mergeCompilerOptions(
  { types: ['node'] },
  { types: { merge: 'replace', value: ['vitest/globals'] } },
)

normalizeCompilerOptions({ types: 'none' }) // { types: [] }
```

`normalizeCompilerOptions` 将控制转成普通数组；空的其他数组省略，显式空 `types: []` 保留。省略 `types` 不会新增限制；显式空数组关闭自动纳入的全局类型。[3]

## Electron + Vite

```ts
import { electronViteInput } from '@infra-x/tsconfig-presets'

const input = electronViteInput('react') // RenderInput
// 将 input 交给调用方的 renderer，例如原 @infra-x/tsconfig 的 renderConfig。
```

`electronViteInput()` 默认使用普通 TypeScript renderer，只接受 `'none'` 和 `'react'`。输入沿用 Electron + Vite 的三个配置布局：

| 配置            | 输入文件                                                       | 类型环境                             |
| --------------- | -------------------------------------------------------------- | ------------------------------------ |
| 根配置          | `files: []`，引用 Node 与 renderer 配置                        | 空 `compilerOptions`                 |
| `node` view     | `src/main/**/*`、`src/preload/**/*`、`electron.vite.config.ts` | DOM 库；`node`、`electron-vite/node` |
| `renderer` view | `src/renderer/**/*`                                            | DOM 库；`vite/client`                |

两个 view 均启用 `strict`、`composite`、Bundler 解析和 `noEmit`，分别使用 `tsconfig.node.tsbuildinfo` 与 `tsconfig.renderer.tsbuildinfo` 缓存。React JSX 只应用于 renderer。项目自行安装 Electron、electron-vite、Vite、`@types/node`，以及需要的 React 依赖。[4]

main 与 preload 共享 DOM 类型，TypeScript 因此允许 main 使用浏览器全局变量。renderer 的 `types` 只限制自动加载的全局声明，无法禁止 Node 或 Electron 导入；这些边界由应用的 lint 规则负责。[3]

公开输入类型为 `CompilerOptions`、`ArrayControl`、`ArrayField`、`ArrayMerge`、`ViewInput`、`RenderInput` 和 `ElectronFramework`。渲染、选项校验、文件冲突检查与写盘由调用方承担。

## 本地验证

在仓库根目录安装依赖后，从本包目录运行：

```sh
bun run test
bun run typecheck
bun run build
```

构建产物为 `dist/index.mjs` 和 `dist/index.d.mts`，通过 ESM `import` 使用。

## 来源

1. [TypeScript 5.4：module preserve](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-5-4.html)
2. [TypeScript 5.0：verbatimModuleSyntax](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-5-0.html)
3. [TypeScript：types 与全局类型可见性](https://www.typescriptlang.org/tsconfig/types.html)
4. [electron-vite：TypeScript 类型声明](https://electron-vite.org/guide/typescript)
