# @infra-x/oxlint-presets

可组合的 Oxlint 预设，包含通用规则、框架规则和 Electron 进程边界检查。由 `@infra-x/code-quality@0.7.0` 的 lint 内容迁入，初始版本保留原有规则行为。

## 本地使用

此包尚未发布。仓库内先安装依赖并构建，再通过 workspace 引用：

```json
{
  "devDependencies": {
    "@infra-x/oxlint-presets": "workspace:*",
    "oxlint": "1.86.0"
  }
}
```

Oxlint 是 peer dependency，要求 `>=1.59.0`；本仓库用 1.86.0 验证。JS 插件是包的运行时依赖，预设从自身安装位置解析插件路径。`nestjs()` 和 `storybook()` 的应用还需提供相应的可选 peer：`class-validator` 和 `storybook >=10`。

创建 `oxlint.config.ts`：

```ts
import { base, unicorn, depend, react, vitest } from '@infra-x/oxlint-presets'
import { defineConfig } from 'oxlint'

export default defineConfig({
  extends: [base(), unicorn(), depend(), react(), vitest()],
})
```

运行 `oxlint`；可修复的问题用 `oxlint --fix`。预设均为函数，按项目需要组合；上例仅展示配置写法。

## 预设

| 类别     | 函数          | 内容                                                           |
| -------- | ------------- | -------------------------------------------------------------- |
| 通用     | `base()`      | TypeScript、Import、规则类别、环境、忽略路径；放在组合最前面   |
| 通用     | `typeAware()` | 启用类型感知检查和类型诊断；只用于根配置                       |
| 通用     | `unicorn()`   | Unicorn 规则及显式风格约束                                     |
| 通用     | `depend()`    | 检查可用原生 API 或更小工具替换的依赖                          |
| Node     | `node()`      | 原生 Node 插件                                                 |
| Node     | `promise()`   | 原生 Promise 插件                                              |
| Electron | `electron()`  | main、preload、renderer 文件环境与导入边界                     |
| 前端     | `react()`     | React 与 Hooks 规则                                            |
| 前端     | `reactVite()` | React 规则和 React Refresh 插件                                |
| 前端     | `nextjs()`    | 原生 Next.js 插件                                              |
| 前端     | `tailwind()`  | Tailwind 类名和换行检查                                        |
| 质量     | `a11y()`      | 原生 JSX 无障碍插件                                            |
| 质量     | `jsdoc()`     | 原生 JSDoc 插件                                                |
| 测试     | `vitest()`    | 测试文件范围内的 Vitest 规则；编辑器中降低跳过、聚焦测试的级别 |
| 测试     | `storybook()` | Storybook JS 插件                                              |
| 后端     | `nestjs()`    | NestJS 注入、Swagger 与装饰器检查                              |
| ORM      | `drizzle()`   | Drizzle delete、update 的 where 检查                           |

同时导出 `defineConfig` 和文件匹配常量：`GLOB_SRC`、`GLOB_JS`、`GLOB_TS`、`GLOB_JSX`、`GLOB_TESTS`、`GLOB_JSON`、`GLOB_MARKDOWN`。

## 自定义和覆盖

预设不修改调用方输入。传入的 `rules` 按规则名整体替换，选项元组不会与默认元组拼接；`undefined` 保留默认值。传入的 `overrides` 追加在默认文件覆盖之后，后置覆盖优先。

其余字段使用 `defu` 深度合并，用户值优先，数组按用户在前、默认在后追加。`vitest({ files })`、`tailwind({ files })` 和 Electron 的三个文件范围选项会替换对应默认数组。

```ts
import { base, unicorn, vitest, tailwind } from '@infra-x/oxlint-presets'
import { defineConfig } from 'oxlint'

export default defineConfig({
  extends: [
    base({ rules: { 'no-console': 'off' } }),
    unicorn({ rules: { 'unicorn/no-array-for-each': 'off' } }),
    vitest({ files: ['**/*.spec.ts', '**/*.e2e-spec.ts'] }),
    tailwind({ entryPoint: 'src/styles/globals.css', rootFontSize: 16 }),
  ],
})
```

`base()` 默认启用 browser 和 Node 环境，忽略生成目录、依赖目录和 `.d.ts`，并读取当前工作目录的 `.gitignore`。它还限制相对父目录导入；项目可以使用路径别名，或在明确范围内覆盖规则。

`vitest()` 根据编辑器环境变量调整聚焦和跳过测试的规则级别，环境变化会影响返回配置。

NestJS 注入参数需要运行时类引用。使用 `nestjs()` 时，应按实际代码在后置文件覆盖中关闭 `typescript/consistent-type-imports`，避免改成类型导入后丢失类引用：

```ts
import { base, nestjs } from '@infra-x/oxlint-presets'
import { defineConfig } from 'oxlint'

export default defineConfig({
  extends: [base(), nestjs()],
  overrides: [
    {
      files: ['**/*.{ts,mts,cts,tsx}'],
      rules: {
        'typescript/consistent-type-imports': 'off',
        'typescript/no-extraneous-class': ['error', { allowWithDecorator: true }],
      },
    },
  ],
})
```

## Electron

使用 `base()` 后接 `electron()`，并把进程预设的 `ignorePatterns` 复制到根配置：

```ts
import { base, electron } from '@infra-x/oxlint-presets'
import { defineConfig } from 'oxlint'

const processConfig = electron()

export default defineConfig({
  extends: [base(), processConfig],
  ignorePatterns: processConfig.ignorePatterns,
})
```

| 选项            | 默认文件范围                                  | 环境和边界                                                                           |
| --------------- | --------------------------------------------- | ------------------------------------------------------------------------------------ |
| `mainFiles`     | `['src/main/**']`                             | Node 开启、browser 关闭；允许 Node 和 Electron 导入                                  |
| `preloadFiles`  | `['src/preload/**']`                          | browser 开启、Node 关闭；额外声明 `require`、`process`、`global`，限制 Node 内置模块 |
| `rendererFiles` | `['src/renderer/**', 'src/shared/**/*.d.ts']` | browser 开启、Node 关闭；限制 Node 全局、Node 内置模块和 Electron 导入               |

这三个数组各自替换默认值。例如 `mainFiles: ['desktop/main/**']` 不再匹配 `src/main/**`；自定义 `rendererFiles` 时须明确保留共享桥接声明。范围之外的文件沿用基础环境，共享运行时代码不自动纳入 renderer。

Oxlint 的 `extends` 不继承 `ignorePatterns`。[1] 根字段使用 `processConfig.ignorePatterns`，可以检查 renderer 和共享桥接声明，同时继续忽略生成文件；复制 `base().ignorePatterns` 会把所有 `.d.ts` 跳过。

renderer 限制 `require` 全局，并检查 Electron 静态导入、再导出、字符串动态导入和无插值模板动态导入，包括 `electron/*`。随包构建的 JS 插件负责动态 Electron 导入检查。[2] 计算得到的模块名和 API 别名需要另行检查；本预设不保证这些调用可被识别。

Electron 类型导入也受限制。桥接接口应独立声明，不导入 Electron 或 Node 类型：

```ts
// src/shared/bridge.d.ts
export interface AppBridge {
  ping(): Promise<string>
}
```

若 renderer 用相对路径引用它，只对这条纯类型导入添加精确例外：

```ts
// src/renderer/bridge.d.ts
// oxlint-disable-next-line import/no-relative-parent-imports -- Shared bridge declaration has no runtime imports.
import type { AppBridge } from '../shared/bridge'

declare global {
  interface Window {
    bridge: AppBridge
  }
}

export {}
```

preload 引用共享类型时也适用同一基础规则，可使用别名或自己的纯类型导入例外。

`electron({ rules })` 按规则名替换三个进程范围内的同名规则，规则选项数组整体替换。传入的 `overrides` 追加在三个默认进程覆盖之后，后置文件覆盖优先。下面只对一个历史文件开放 `fs`：

```ts
const processConfig = electron({
  overrides: [
    {
      files: ['src/preload/legacy.ts'],
      rules: {
        'import/no-nodejs-modules': ['error', { allow: ['fs'] }],
      },
    },
  ],
})
```

React 规则可以只作用于 renderer。保留该范围需要的完整原生插件列表，只复制兼容文件覆盖的字段：

```ts
import { base, electron, reactVite } from '@infra-x/oxlint-presets'
import { defineConfig } from 'oxlint'

const rendererFiles = ['src/renderer/**']
const rendererReact = reactVite()
const processConfig = electron({
  rendererFiles: [...rendererFiles, 'src/shared/**/*.d.ts'],
  overrides: [
    {
      files: rendererFiles,
      plugins: ['typescript', 'import', ...(rendererReact.plugins ?? [])],
      jsPlugins: rendererReact.jsPlugins,
      rules: rendererReact.rules,
    },
  ],
})

export default defineConfig({
  extends: [base(), processConfig],
  ignorePatterns: processConfig.ignorePatterns,
})
```

文件覆盖可使用 `plugins`、`jsPlugins`、`rules`、`env`、`globals`；不要把整个预设展开进去，`extends`、`categories`、`settings` 属于根配置。

preload 是保守检查基线，声明 `require` 和 `process` 不表示拥有全部 Node 能力。实际权限取决于 Electron 版本、sandbox 和窗口配置。[3] 本包不配置 `BrowserWindow`，不验证 IPC 载荷，也不保证 Electron 运行安全；context isolation 和桥接 API 需单独评审。[4]

## 类型感知与多包配置

`typeAware()` 返回 `options.typeAware` 和 `options.typeCheck`。把它展开到根配置，明确启用这两个根级选项：

```ts
import { base, typeAware, unicorn } from '@infra-x/oxlint-presets'
import { defineConfig } from 'oxlint'

export default defineConfig({
  ...typeAware(),
  extends: [base(), unicorn()],
})
```

`oxlint-tsgolint` 已作为依赖包含；类型引擎要求配置兼容 TypeScript 7，并可能拒绝旧选项。[5] `options.typeAware` 和 `options.typeCheck` 只能放在根配置。多包仓库的子配置需显式继承根配置；自动查找使用最近配置，传入 `--config` 会关闭嵌套查找。[1]

保留独立 `tsc --noEmit` 时，可覆盖完整 tsconfig 文件范围和项目级配置诊断；它的检查范围与 lint 遍历范围可能不同。

## 本仓库验证

在本包目录运行：

```sh
bun run typecheck
bun run test
```

`test` 先构建，再运行真实 Oxlint CLI 用例，包括默认和自定义文件范围、规则替换、React 组合、声明文件、生成目录忽略，以及 npm tarball 内的 Electron 插件加载。构建同时输出 `index.mjs`、公开声明和内部 `electron-plugin.mjs`；插件不作为公开子路径导出。

格式配置由独立的 `@infra-x/oxfmt-presets` 提供；本包仅包含 lint 内容。

## 来源

1. [Oxlint：Nested configuration files](https://oxc.rs/docs/guide/usage/linter/nested-config.html)
2. [Oxlint：Writing JS Plugins](https://oxc.rs/docs/guide/usage/linter/writing-js-plugins.html)
3. [Electron：Process Sandboxing](https://www.electronjs.org/docs/latest/tutorial/sandbox)
4. [Electron：Security](https://www.electronjs.org/docs/latest/tutorial/security)
5. [Oxlint：Type-Aware Linting](https://oxc.rs/docs/guide/usage/linter/type-aware.html)

MIT
