# @infra-x/oxfmt-presets

通用 Oxfmt 格式预设和 Tailwind 类排序选项。该包只依赖 `defu`，不安装任何 lint 预设或插件。

当前包尚未发布。可以在本地 workspace 使用：

```ts
// oxfmt.config.ts
import { format } from '@infra-x/oxfmt-presets'
import { defineConfig } from 'oxfmt'

export default defineConfig(format())
```

默认使用无分号、单引号、两空格缩进、100 字符行宽，并排序 imports 与 package.json。需要调整时传入覆盖值，其余默认值保留：

```ts
export default defineConfig(format({ semi: true, printWidth: 120 }))
```

覆盖时标量由用户值替换，普通对象深度合并，数组整体替换；空数组可清除默认列表。函数不修改传入对象。例如完整指定 import 顺序并清除默认内部路径匹配：

```ts
export default defineConfig(
  format({
    sortImports: { groups: ['external', 'builtin'], internalPattern: [] },
  }),
)
```

Tailwind 项目指定实际入口样式文件：

```ts
import { format, tailwindFormat } from '@infra-x/oxfmt-presets'
import { defineConfig } from 'oxfmt'

export default defineConfig({
  ...format(),
  ...tailwindFormat({ stylesheet: 'src/app.css' }),
})
```

类排序会识别 `cn`、`clsx`、`cva`、`tw`。Oxfmt 是 peer 依赖（`>=0.44.0`），当前使用 `0.71.0` 验证。格式检查使用 `oxfmt --check .`，修改格式使用 `oxfmt --write .`。
